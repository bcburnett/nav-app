package com.newlondonweb.tabbedfragmentdemo.data.letters

enum class Command {INPLAY,WON,LOST}
